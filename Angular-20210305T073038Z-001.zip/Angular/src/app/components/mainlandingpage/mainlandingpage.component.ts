import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainlandingpage',
  templateUrl: './mainlandingpage.component.html',
  styleUrls: ['./mainlandingpage.component.css']
})
export class MainlandingpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
