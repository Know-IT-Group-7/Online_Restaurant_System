export class Product{
    product_id:number;
    product_nm:string;
    category:string;
    subcategory:string;
    product_desc:string;

    /*constructor(product_id:number, product_nm:string, category:string, subcategory:string, product_desc:string)
    {
        this.product_id = product_id;
        this.product_nm=product_nm;
        this.category=category;
        this.subcategory=subcategory;
        this.product_desc=product_desc;
        
    }*/
   
}