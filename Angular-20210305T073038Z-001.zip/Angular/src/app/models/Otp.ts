export class Otp 
{
    otp:number;
    constructor(otp?:number){}
}