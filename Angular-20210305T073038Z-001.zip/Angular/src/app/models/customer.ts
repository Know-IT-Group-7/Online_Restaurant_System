import { __exportStar } from "tslib";

export class Customer
{
    customer_id:number;
    first_nm:string;
    last_nm:string;
    contact:string;
    email:string;
    password:string;
    address:string;
}