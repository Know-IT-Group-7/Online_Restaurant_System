 export class Restmgr {
    authority_id : number;
    first_nm : string;
    last_nm : string;
    password : string;
    contact_no : string;
    email : string;
}