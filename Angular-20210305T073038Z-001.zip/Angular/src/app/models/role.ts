export class Role {
   role_id;
   role_name;
}