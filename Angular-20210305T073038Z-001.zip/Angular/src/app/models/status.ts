export class Status
{
    status_id:number;
    status_name:string;
    constructor(id?:number,nm?:string)
    {
        this.status_id=id;
        this.status_name=nm;
    }
}