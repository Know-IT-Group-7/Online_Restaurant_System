export class ViewCustomer
{
    customer_id:string;
    first_nm:string;
    last_nm:string;
    contact:string;
    email:string;
    password:string;
    address:string;
}