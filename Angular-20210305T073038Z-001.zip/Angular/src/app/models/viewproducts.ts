import { Product } from "./product";
import { Restaurant } from "./restaurant";

export class ViewProduct{
    r_product_id:number;
    unit_price:number;
    product:Product;
    restaurant:Restaurant;
}