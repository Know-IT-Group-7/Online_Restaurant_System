export class ViewTransaction
{
    order_id:number;
    date:Date;
    total_amount:number;
    payment_mode:string;
    payment_status:string;
    customer_id:number;
    status_id:number;
    restaurant_id:number;
}