export class website_admin
{
    admin_id : number;
    user_id :string;
    password : string;
    first_nm : string;
    last_nm : string;
    contact: string;
    email : string;
   

}